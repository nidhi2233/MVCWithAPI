using System;
using System.Collections.Generic;
using System.IdentityModel.Tokens.Jwt;
using System.Linq;
using System.Security.Claims;
using System.Text;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization.Infrastructure;
using Microsoft.AspNetCore.Mvc;
using Microsoft.IdentityModel.Tokens;
using Repositories;

namespace API.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class UserController : ControllerBase
    {
        private readonly IUserInterface _userRepo;
        private readonly IConfiguration _configer;
        public UserController(IUserInterface userRepo,IConfiguration configuration)
        {
            _configer = configuration;
            _userRepo = userRepo;
        }

        [HttpGet]
        public async Task<IActionResult> GetAllUsers()
        {
            try
            {
                var users = await _userRepo.GetAllUser();
                return Ok(new { success = true, allUsers = users });
            }
            catch (Exception ex)
            {
                return BadRequest(new { success = false, message = ex.Message });
            }
        }

        [HttpPost]
        [Route("Register")]
        public async Task<IActionResult> Rigister([FromForm] t_User user)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    if (user.imageFile != null && user.imageFile.Length > 0)
                    {
                        var fileName = user.email + Path.GetExtension(user.imageFile.FileName);
                        var filPath = Path.Combine("../MVC/wwwroot/profile_image", fileName);
                        user.image = fileName.ToString();
                        using (var stram = new FileStream(filPath, FileMode.Create))
                        {
                            await user.imageFile.CopyToAsync(stram);
                        }
                    }
                    var status = await _userRepo.Register(user);
                    if (status == 1)
                    {
                        return Ok(new { success = true, message = "User Registered" });
                    }
                    else if (status == 2)
                    {
                        return Ok(new { success = false, message = "User Already Exist" });
                    }
                    else
                    {
                        return BadRequest(new { success = false, message = "There Was some error while Registered" });
                    }
                }
                return Ok();
            }
            catch (Exception ex)
            {
                throw new Exception(ex.ToString());
            }
        }


        [HttpPost]
        [Route("Login")]
        public async Task<IActionResult> Login([FromForm] vm_Login login)
        {
            if (ModelState.IsValid)
            {
                var user = await _userRepo.Login(login);
                if (user.userId != 0)
                {
                    var claims = new[]{
                        new Claim(JwtRegisteredClaimNames.Jti, Guid.NewGuid().ToString()),
                        new Claim("userId",user.userId.ToString()),
                        new Claim("userName",user.userName),
                    };
                    var key = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(_configer["Jwt:Key"]!));
                    var signIn = new SigningCredentials(key,SecurityAlgorithms.HmacSha256);
                    var token = new JwtSecurityToken(
                        issuer : _configer["Issuer"],
                        audience: _configer["Audience"],
                        claims: claims,
                        expires: DateTime.UtcNow.AddDays(1),
                        signingCredentials:signIn
                    );
                    return Ok(new { success = true, alldata = user, message = "Login successfull Done." , token = new JwtSecurityTokenHandler().WriteToken(token)});
                }
                else
                {
                    return Ok(new { success = false, message = "User Not Exist" }); 
                }
            }
            return Ok();
        }
    }
}
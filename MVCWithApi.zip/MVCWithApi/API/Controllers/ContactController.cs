using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Repositories;
using Repositories.Interface;

namespace API.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class ContactController : ControllerBase
    {
        private readonly IContactInterface _contactRepo;

        public ContactController(IContactInterface contactRepo)
        {
            _contactRepo = contactRepo;
        }

        [HttpGet("GetAllContactAndById/{id}")]
        public async Task<IActionResult> GetAllContactAndById(int id)
        {
            try
            {
                var contact = await _contactRepo.GetAllContactAndById(id);
                return Ok(new { success = true, allContact = contact });
            }
            catch (Exception ex)
            {
                return BadRequest(new { success = false, message = ex.Message });
            }
        }

        [HttpGet("GetContactById/{id}")]
        public async Task<IActionResult> GetContactById(int id)
        {
            try
            {
                var con = await _contactRepo.GetContactById(id);
                return Ok(new { success = true, contact = con });
            }
            catch (Exception ex)
            {
                return BadRequest(new { success = false, message = ex.Message });
            }
        }

        [HttpPost("AddContact")]
        public async Task<IActionResult> AddContact([FromForm] t_contact contact)
        {
            try
            {
                int status = 0;
                status = await _contactRepo.CheckContact(contact);
                if (status == 0)
                {
                    if (contact.imageFile != null && contact.imageFile.Length > 0)
                    {
                        var fileName = contact.contactname + Path.GetExtension(contact.imageFile.FileName);
                        var filPath = Path.Combine("../MVC/wwwroot/contact_image", fileName);
            
                        contact.image = fileName.ToString();
                        using (var stram = new FileStream(filPath, FileMode.Create))
                        {
                            await contact.imageFile.CopyToAsync(stram);
                        }
                    }
                    status = await _contactRepo.AddContact(contact);
                    if (status == 1)
                    {
                        return Ok(new { success = true, message = "Contact Added" });
                    }
                    else
                    {
                        return BadRequest(new { success = false, message = "There Was some error while Registered" });
                    }
                }
                else if (status == 2)
                {
                    return Ok(new { success = false, message = "Contact Name Is Exist." });
                }
                else if (status == 3)
                {
                    return Ok(new { success = false, message = "Mobile Number Is Exist." });
                }
                else
                {
                    return BadRequest(new { success = false, message = "There Was some error while Registered" });
                }
            }
            catch (Exception ex)
            {
                return BadRequest(new { success = false, message = ex.Message });
            }
        }

        [HttpPut("UdpateContact")]
        public async Task<IActionResult> UdpateContact([FromForm] t_contact contact)
        {
            try
            {
                if (contact.imageFile != null && contact.imageFile.Length > 0)
                {
                    var fileName = contact.contactname + Path.GetExtension(contact.imageFile.FileName);
                    var filPath = Path.Combine("../MVC/wwwroot/contact_image", fileName);
                    contact.image = fileName.ToString();

                    using (var stram = new FileStream(filPath, FileMode.Create))
                    {
                        await contact.imageFile.CopyToAsync(stram);
                    }
                }
                int status = await _contactRepo.UpdateContact(contact);
                if (status == 1)
                {
                    return Ok(new { success = true, message = "Contact Updated." });
                }
                else
                {
                    return BadRequest(new { success = false, message = "There Was some error while Registered" });
                }
            }
            catch (Exception ex)
            {
                return BadRequest(new
                {
                    success = false,
                    message = ex.Message
                });
            }
        }

        [HttpDelete("DeleteContact/{id}")]
        public async Task<IActionResult> DeleteContact(int id)
        {
            try
            {
                int status = await _contactRepo.DelteContact(id);
                if (status == 1)
                {
                    return Ok(new { success = true, message = "Contact Deleted." });
                }
                else
                {
                    return BadRequest(new { success = false, message = "There Was some error while Registered" });
                }
            }
            catch (Exception ex)
            {
                return BadRequest(new { success = false, message = ex.Message });
            }
        }
    }
}
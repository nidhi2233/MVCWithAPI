﻿using System.ComponentModel.DataAnnotations;
namespace Repositories;

public class vm_Login
{
    [StringLength(100)]
    [Required(ErrorMessage = "Email is Requierd")]
    [EmailAddress(ErrorMessage = "Invalid Email Format.")]
    public string email { get; set;} = null!;

    [StringLength(100)]
    [Required(ErrorMessage = "Password is Requierd")]
    public string password { get; set;} = null!;
}

﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.AspNetCore.Http;

namespace Repositories;

public class t_User
{

    [Key]
    [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
    public int userId { get; set;}

    [MaxLength(20)]
    [Required(ErrorMessage = "User Name is Requierd")]
    public string userName { get; set;} = null!;

    [MaxLength(100)]
    [Required(ErrorMessage = "Email is Requierd")]
    [EmailAddress(ErrorMessage = "Invalid Email Format.")]
    public string email { get; set;} = null!;

    [MaxLength(100)]
    [Required(ErrorMessage = "Password is Requierd")] 
    public string password { get; set;} = null!;

    [MaxLength(100)]
    [Required(ErrorMessage = "Confirom Password is Requierd")]
    [Compare("password", ErrorMessage = "Password Is Miss Match")]
    public string? confirmPassword { get; set;}

    [MaxLength(200)]
    public string? address { get; set;}

    [MaxLength(10)]
    public string? mobile { get; set;}
    public IFormFile? imageFile{ get; set;}

    [MaxLength(100)]
    public string? image { get; set;}

    [MaxLength(10)]
    public string? gender { get; set;}
}

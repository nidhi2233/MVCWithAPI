﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.AspNetCore.Http;

namespace Repositories;

public class t_contact
{
    [Key]
    [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
    public int contactId { get; set; } = 0;


    [Required(ErrorMessage = "UserId is Requierd")]
    public int userId { get; set; }

    [MaxLength(20)]
    [Required(ErrorMessage = "Contact Name is Requierd")]
    public string contactname { get; set; } = null!;

    [MaxLength(100)]
    [EmailAddress(ErrorMessage = "Invalid Email Format.")]
    public string email { get; set; } = null!;

    [MaxLength(200)]
    public string address { get; set; } = null!;

    [MaxLength(10)]
    public string mobile { get; set; } = null!;

    public IFormFile? imageFile { get; set; }

    [MaxLength(100)]
    public string? image { get; set; }

    [MaxLength(100)]
    public string group { get; set; } = null!;
    [MaxLength(10)]
    public string status { get; set; } = null!;
}

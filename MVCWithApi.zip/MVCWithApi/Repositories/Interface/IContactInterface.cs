using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Repositories.Interface
{
    public interface IContactInterface
    {
        public Task<List<t_contact>> GetAllContactAndById(int id); 
        public Task<int> AddContact(t_contact t_Contact); 
        public Task<int> UpdateContact(t_contact t_Contact); 
        public Task<int> CheckContact(t_contact t_Contact);
        public Task<int> DelteContact(int id);
        public Task<t_contact> GetContactById(int id);
    }
}
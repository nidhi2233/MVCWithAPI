﻿namespace Repositories;

public interface IUserInterface
{
    public Task<int> Register(t_User user);
    public Task<t_User> Login(vm_Login login);
    public Task<List<t_User>> GetAllUser();
}

using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Npgsql;
using Repositories.Interface;

namespace Repositories.Implementation
{
    public class ContactRepository : IContactInterface
    {
        private readonly NpgsqlConnection _connection;
        public ContactRepository(NpgsqlConnection connection)
        {
            _connection = connection;
        }

        public async Task<List<t_contact>> GetAllContactAndById(int id)
        {
            try
            {
                List<t_contact> contacts = new List<t_contact>();
                await _connection.OpenAsync();
                string qurey = null!;
                if (id > 0)
                {
                    qurey = @"SELECT c_contact_id, c_contactname, c_email, c_address, c_moblie, c_group, c_image,c_status
	                FROM public.t_contact WHERE c_user_id = @c_user_id";
                }
                else
                {
                    qurey = @"SELECT c_contact_id, c_contactname, c_email, c_address, c_moblie, c_group, c_image,c_status
	                FROM public.t_contact";
                }

                using (var command = new NpgsqlCommand(qurey, _connection))
                {
                    command.Parameters.AddWithValue("c_user_id", id);
                    using (var dataReader = await command.ExecuteReaderAsync())
                    {
                        while (dataReader.Read())
                        {
                            contacts.Add(new t_contact
                            {
                                contactId = Convert.ToInt32(dataReader["c_contact_id"]),
                                contactname = dataReader["c_contactname"].ToString()!,
                                email = dataReader["c_email"].ToString()!,
                                address = dataReader["c_address"].ToString()!,
                                group = dataReader["c_group"].ToString()!,
                                image = dataReader["c_image"].ToString()!,
                                mobile = dataReader["c_moblie"].ToString()!,
                                status = dataReader["c_status"].ToString()!
                            });
                        }
                    }
                }
                return contacts;
            }
            catch (Exception ex)
            {
                throw new Exception($"Error in Get All Contact: {ex.Message}");
            }
            finally
            {
                await _connection.CloseAsync();
            }
        }


        public async Task<int> AddContact(t_contact t_Contact)
        {
            try
            {
                int status = 0;
                await _connection.OpenAsync();
                string qurey = @"INSERT INTO public.t_contact(
                c_user_id, c_contactname, c_email, c_address, c_moblie, c_group, c_image,c_status)
                VALUES (@c_user_id, @c_contactname, @c_email, @c_address, @c_moblie, @c_group, @c_image,@c_status);";

                using (var command = new NpgsqlCommand(qurey, _connection))
                {
                    command.Parameters.AddWithValue("c_user_id", t_Contact.userId);
                    command.Parameters.AddWithValue("c_contactname", t_Contact.contactname);
                    command.Parameters.AddWithValue("c_email", t_Contact.email);
                    command.Parameters.AddWithValue("c_address", t_Contact.address);
                    command.Parameters.AddWithValue("c_moblie", t_Contact.mobile);
                    command.Parameters.AddWithValue("c_group", t_Contact.group);
                    command.Parameters.AddWithValue("c_status", t_Contact.status);
                    command.Parameters.AddWithValue("c_image", t_Contact.image == null ? DBNull.Value : t_Contact.image);
                    int result = await command.ExecuteNonQueryAsync();
                    if (result > 0)
                    {
                        status = 1;
                    }
                }
                return status;
            }
            catch (Exception ex)
            {
                throw new Exception($"Error in Add New Contact: {ex.Message}");
            }
            finally
            {
                await _connection.CloseAsync();
            }
        }



        public async Task<int> UpdateContact(t_contact t_Contact)
        {
            try
            {
                int status = 0;
                await _connection.OpenAsync();
                string qurey = @"UPDATE public.t_contact
                SET c_contactname=@c_contactname, c_email=@c_email, c_address=@c_address, c_moblie=@c_moblie, c_group=@c_group, c_image=@c_image ,c_status=@c_status
                WHERE c_contact_id=@c_contact_id;";

                using (var command = new NpgsqlCommand(qurey, _connection))
                {
                    command.Parameters.AddWithValue("c_contact_id", t_Contact.contactId);
                    command.Parameters.AddWithValue("c_contactname", t_Contact.contactname);
                    command.Parameters.AddWithValue("c_email", t_Contact.email);
                    command.Parameters.AddWithValue("c_address", t_Contact.address);
                    command.Parameters.AddWithValue("c_moblie", t_Contact.mobile);
                    command.Parameters.AddWithValue("c_group", t_Contact.group);
                    command.Parameters.AddWithValue("c_status", t_Contact.status);
                    command.Parameters.AddWithValue("c_image", t_Contact.image == null ? DBNull.Value : t_Contact.image);
                    int result = await command.ExecuteNonQueryAsync();
                    if (result > 0)
                    {
                        status = 1;
                    }
                }
                return status;
            }
            catch (Exception ex)
            {
                throw new Exception($"Error in Update Contact: {ex.Message}");
            }
            finally
            {
                await _connection.CloseAsync();
            }
        }

        public async Task<int> CheckContact(t_contact t_Contact)
        {
            try
            {
                int status = 0;
                bool check = false;
                await _connection.OpenAsync();
                string qurey = null!;

                if (t_Contact.contactname != null)
                {
                    qurey = "SELECT * FROM public.t_contact WHERE c_contactname = @c_contactname;";
                    status = 2;
                }
                else if (t_Contact.mobile != null)
                {
                    qurey = "SELECT * FROM public.t_contact WHERE c_moblie = @c_moblie;";
                    status = 3;
                }
                else
                {
                    status = 0;
                }

                if (qurey != null)
                {
                    using (var command = new NpgsqlCommand(qurey, _connection))
                    {
                        command.Parameters.AddWithValue("c_contactname", t_Contact.contactname!);
                        command.Parameters.AddWithValue("c_moblie", t_Contact.mobile!);
                        using (var dataReader = await command.ExecuteReaderAsync())
                        {
                            if (dataReader.HasRows)
                            {
                                check = true;
                            }
                        }
                    }
                }

                if (!check)
                {
                    status = 0;
                }
                return status;
            }
            catch (Exception ex)
            {
                throw new Exception($"Error in Check Contact: {ex.Message}");
            }
            finally
            {
                await _connection.CloseAsync();
            }
        }

        public async Task<int> DelteContact(int id)
        {
            try
            {
                int status = 0;
                await _connection.OpenAsync();
                using (var command = new NpgsqlCommand("DELETE FROM public.t_contact WHERE c_contact_id = @c_contact_id;", _connection))
                {
                    command.Parameters.AddWithValue("c_contact_id", id);
                    int result = await command.ExecuteNonQueryAsync();
                    if (result > 0)
                    {
                        return 1;
                    }
                }
                return status;
            }
            catch (Exception ex)
            {
                throw new Exception($"Error in Delete Contact: {ex.Message}");
            }
            finally
            {
                await _connection.CloseAsync();
            }
        }

        public async Task<t_contact> GetContactById(int id)
        {

            try
            {
                await _connection.OpenAsync();
                t_contact contact = new t_contact();
                using (var command = new NpgsqlCommand(@"SELECT c_contact_id,  c_contactname, c_email, c_address, c_moblie, c_group, c_image, c_status
	            FROM public.t_contact where c_contact_id=@c_contact_id;", _connection))
                {
                    command.Parameters.AddWithValue("c_contact_id", id);
                    using (var dataReader = await command.ExecuteReaderAsync())
                    {
                        while (dataReader.Read())
                        {

                            contact.contactId = Convert.ToInt32(dataReader["c_contact_id"]);
                            contact.contactname = dataReader["c_contactname"].ToString()!;
                            contact.email = dataReader["c_email"].ToString()!;
                            contact.address = dataReader["c_address"].ToString()!;
                            contact.group = dataReader["c_group"].ToString()!;
                            contact.image = dataReader["c_image"].ToString()!;
                            contact.mobile = dataReader["c_moblie"].ToString()!;
                            contact.status = dataReader["c_status"].ToString()!;
                        }
                    }
                }
                return contact;
            }
            catch (Exception ex)
            {
                throw new Exception($"Error in Get All Contact: {ex.Message}");
            }
            finally
            {
                await _connection.CloseAsync();
            }
        }
    }
}
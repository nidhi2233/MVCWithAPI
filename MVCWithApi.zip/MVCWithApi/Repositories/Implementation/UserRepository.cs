﻿
using Microsoft.AspNetCore.Http;
using Npgsql;

namespace Repositories;

public class UserRepository : IUserInterface
{
    private readonly NpgsqlConnection _connection;
    public UserRepository(NpgsqlConnection connection)
    {
        _connection = connection;
    }

    public async Task<List<t_User>> GetAllUser()
    {
        try
        {
            await _connection.OpenAsync();
            List<t_User> Users = new List<t_User>();

            using (var command = new NpgsqlCommand(@"SELECT c_user_id, c_username, c_email, c_password, c_address, c_mobile, c_image, c_gender
	        FROM public.t_user", _connection))
            {
                using (var dataReader = await command.ExecuteReaderAsync())
                {
                    while (dataReader.Read())
                    {
                        Users.Add(new t_User
                        {
                            userId = Convert.ToInt32(dataReader["c_user_id"]),
                            userName = dataReader["c_username"].ToString()!,
                            email = dataReader["c_email"].ToString()!,
                            address = dataReader["c_address"].ToString()!,
                            password = dataReader["c_password"].ToString()!,
                            image = dataReader["c_image"].ToString()!,
                            mobile = dataReader["c_mobile"].ToString()!,
                            gender = dataReader["c_gender"].ToString()!,
                        });
                    }
                }
            }
            return Users;
        }
        catch (Exception ex)
        {
            throw new Exception($"Error in Get All User: {ex.Message}");
        }
        finally
        {
            await _connection.CloseAsync();
        }
    }

    public async Task<t_User> Login(vm_Login login)
    {
        try
        {
            t_User user = new t_User();
            await _connection.OpenAsync();

            using (var command = new NpgsqlCommand("SELECT c_user_id,c_username,c_email FROM t_user WHERE c_email = @c_email AND c_password = @c_password;", _connection))
            {
                command.Parameters.AddWithValue("c_email", login.email);
                command.Parameters.AddWithValue("c_password", login.password);
                using (var dataReader = await command.ExecuteReaderAsync())
                {
                    if (dataReader.HasRows)
                    {
                        if (await dataReader.ReadAsync())
                        {
                            user = new t_User
                            {
                                userId = dataReader.GetInt32(dataReader.GetOrdinal("c_user_id")),
                                userName = dataReader.GetString(dataReader.GetOrdinal("c_username")),
                                email = dataReader.GetString(dataReader.GetOrdinal("c_email"))
                            };
                        }

                    }
                }
            }
            return user;
        }
        catch (Exception ex)
        {
            throw new Exception($"Error in Login: {ex.Message}");
        }
        finally
        {
            await _connection.CloseAsync();
        }
    }

    public async Task<int> Register(t_User user)
    {
        int status = 0;
        try
        {
            await _connection.OpenAsync();

            using (var command = new NpgsqlCommand("SELECT * FROM t_user WHERE c_email = @c_email;", _connection))
            {
                command.Parameters.AddWithValue("c_email", user.email);
                using (var dataReader = await command.ExecuteReaderAsync())
                {
                    if (dataReader.HasRows)
                    {
                        return 2;
                    }
                }
            }

            using (var insertCommand = new NpgsqlCommand(@"INSERT INTO public.t_user(
            c_username, c_email, c_password, c_address, c_mobile, c_image, c_gender)
            VALUES (@c_username, @c_email, @c_password, @c_address, @c_mobile, @c_image, @c_gender)", _connection))
            {
                insertCommand.Parameters.AddWithValue("c_username", user.userName);
                insertCommand.Parameters.AddWithValue("c_email", user.email);
                insertCommand.Parameters.AddWithValue("c_password", user.password);
                insertCommand.Parameters.AddWithValue("c_address", user.address==null ? DBNull.Value : user.address);
                insertCommand.Parameters.AddWithValue("c_mobile", user.mobile==null ? DBNull.Value : user.mobile);
                insertCommand.Parameters.AddWithValue("c_image", user.image==null ? DBNull.Value : user.image);
                insertCommand.Parameters.AddWithValue("c_gender", user.gender ==null ? DBNull.Value : user.gender);

                int result = await insertCommand.ExecuteNonQueryAsync();
                if (result > 0)
                {
                    status = 1;
                }
            }

            return status;
        }
        catch (Exception ex)
        {
            throw new Exception($"Error in Register: {ex.Message}");
        }
        finally
        {
            await _connection.CloseAsync();
        }
    }
}

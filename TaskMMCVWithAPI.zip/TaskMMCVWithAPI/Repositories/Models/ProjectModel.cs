using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace Repositories.Models
{
    public class ProjectModel
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int projectId { get; set; }

        [MaxLength(200)]
        [Required(ErrorMessage = "Enter Project Title.")]
        public string projectName { get; set; } = null!;

        [MaxLength(200)]
        [Required(ErrorMessage = "Enter Project Description.")]
        public string description { get; set; } = null!;
    }
}
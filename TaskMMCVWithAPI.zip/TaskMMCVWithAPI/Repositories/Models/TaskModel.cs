using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace Repositories.Models
{
    public class TaskModel
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int taskId { get; set; } = 0;
        [Required(ErrorMessage = "Select any One Project.")]
        public int projectId { get; set; }
        [Required(ErrorMessage = "Select any One Employee.")]
        public int empId{ get; set; }

        [MaxLength(200)]
        [Required(ErrorMessage = "Enter Task Title.")]
        public string title { get; set; } = null!;

        [MaxLength(200)]
        [Required(ErrorMessage = "Enter Task Description.")]
        public string description { get; set; } =null!;

        [Required(ErrorMessage = "Enter Task Compliance EstimatedDay.")]
        public int estimatedDay { get; set; }

        public DateTime? startDate{ get; set; }
        public DateTime? endDate{ get; set; }
        public string? status { get; set; }
        public ProjectModel? project{get; set; }
        public EmployeeModel? employee{ get; set; }
    }
}
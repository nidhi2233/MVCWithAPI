using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace Repositories.Models
{
    public class Vm_login
    {
        [MaxLength(200)]
        [Required(ErrorMessage = "Enter Email Address.")]
        [EmailAddress(ErrorMessage = "Invalid Email Formate")]
        public string email { get; set; } =null!;
        
        [Required(ErrorMessage = "Password is Required")]
        public string password { get; set; } =null!;
    }
}
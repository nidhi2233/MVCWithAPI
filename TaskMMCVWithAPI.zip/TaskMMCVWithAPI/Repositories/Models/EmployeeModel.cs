using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Http.Internal;

namespace Repositories.Models
{
    public class EmployeeModel
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int empId { get; set; }

        [MaxLength(200)]
        [Required(ErrorMessage = "Enter Name.")]
        [RegularExpression(@"^[a-zA-Z]+$", ErrorMessage = "Only alphabets are allowed for the name.")]
        public string name { get; set; } = null!;

        [MaxLength(200)]
        [Required(ErrorMessage = "Enter Email Address.")]
        [EmailAddress(ErrorMessage = "Invalid Email Formate")]
        public string email { get; set; } = null!;

        [MinLength(8, ErrorMessage = "Set Minimum 8 Character")]
        [MaxLength(16, ErrorMessage = "set Maxmum 16 Character")]
        [Required(ErrorMessage = "Enter Task Compliance EstimatedDay.")]
        public string password { get; set; } = null!;
    
        [MinLength(8, ErrorMessage = "Set Minimum 8 Character")]
        [MaxLength(16, ErrorMessage = "set Maxmum 16 Character")]
        [Compare("password",ErrorMessage ="Password Is Miss Match")]
        [Required(ErrorMessage = "Enter Task Compliance EstimatedDay.")]
        public string confirmPassword { get; set; } = null!;

        [MaxLength(20)]
        public string? role { get; set; }
        public IFormFile? formFile { get; set; }
        public string? profileImage { get; set; }
    }
}
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Npgsql;
using Repositories.InterFace;
using Repositories.Models;

namespace Repositories.implementation
{
    public class ProjectRepository : IProjectInterFace
    {

        private readonly NpgsqlConnection _connection;

        public ProjectRepository(NpgsqlConnection connection)
        {
            _connection = connection;
        }
        public async Task<ResponseModel<string>> AddProject(ProjectModel project)
        {
            ResponseModel<string> response = new ResponseModel<string>();
            try
            {
                await _connection.OpenAsync();
                using (NpgsqlCommand command = new NpgsqlCommand(@"INSERT INTO taskm.t_project(
                c_project_name, c_description)
                VALUES (@c_project_name, @c_description);", _connection))
                {
                    command.Parameters.AddWithValue("c_project_name", project.projectName);
                    command.Parameters.AddWithValue("c_description", project.description);
                    var result = await command.ExecuteNonQueryAsync();
                    if (result > 0)
                    {
                        response.success = true;
                        response.message = "Record Inserted Succsessfully.";
                    }
                    else
                    {
                        response.success = false;
                        response.message = "Getting error while registration.";
                    }
                }

            }
            catch (Exception ex)
            {
                response.message = ex.Message;
                response.success = false;
            }
            finally
            {
                await _connection.CloseAsync();
            }
            return response;
        }

        public async Task<ResponseModel<string>> DeleteProject(int id)
        {
            ResponseModel<string> response = new ResponseModel<string>();
            try
            {
                await _connection.OpenAsync();
                using (NpgsqlCommand command = new NpgsqlCommand(@"DELETE FROM taskm.t_project WHERE c_project_id=@c_project_id;", _connection))
                {
                    command.Parameters.AddWithValue("c_project_id", id);
                    var result = await command.ExecuteNonQueryAsync();
                    if (result > 0)
                    {
                        response.success = true;
                        response.message = "Record Deleted Succsessfully.";
                    }
                    else
                    {
                        response.success = false;
                        response.message = "Getting error while deleteing.";
                    }
                }

            }
            catch (Exception ex)
            {
                response.message = ex.Message;
                response.success = false;
            }
            finally
            {
                await _connection.CloseAsync();
            }
            return response;
        }

        public async Task<ResponseModel<List<ProjectModel>>> GetAllProject()
        {
            ResponseModel<List<ProjectModel>> response = new ResponseModel<List<ProjectModel>>();
            List<ProjectModel> listProject = new List<ProjectModel>();
            try
            {
                await _connection.OpenAsync();
                using (NpgsqlCommand command = new NpgsqlCommand("SELECT c_project_id, c_project_name, c_description FROM taskm.t_project;", _connection))
                {
                    NpgsqlDataReader dataReader = await command.ExecuteReaderAsync();
                    if (dataReader.HasRows)
                    {
                        while (dataReader.Read())
                        {
                            listProject.Add(new ProjectModel
                            {
                                projectId = Convert.ToInt32(dataReader["c_project_id"]),
                                projectName = dataReader["c_project_name"].ToString()!,
                                description = dataReader["c_description"].ToString()!,
                            });
                        }
                        response.message = "";
                        response.success = true;
                        response.data = listProject;
                    }
                    else
                    {
                        response.message = "No records found";
                        response.success = false;
                    }
                }

            }
            catch (Exception ex)
            {
                response.message = ex.Message;
                response.success = false;
            }
            finally
            {
                await _connection.CloseAsync();
            }
            return response;
        }

        public async Task<ResponseModel<ProjectModel>> GetProjectById(int id)
        {
            ResponseModel<ProjectModel> response = new ResponseModel<ProjectModel>();
            ProjectModel project = new ProjectModel();
            try
            {
                await _connection.OpenAsync();
                using (NpgsqlCommand command = new NpgsqlCommand("SELECT c_project_id, c_project_name, c_description FROM taskm.t_project WHERE c_project_id=@c_project_id", _connection))
                {
                    command.Parameters.AddWithValue("c_project_id", id);
                    NpgsqlDataReader dataReader = await command.ExecuteReaderAsync();
                    if (dataReader.HasRows)
                    {
                        while (dataReader.Read())
                        {
                                project.projectId = Convert.ToInt32(dataReader["c_project_id"]);
                                project.projectName = dataReader["c_project_name"].ToString()!;
                                project.description = dataReader["c_description"].ToString()!;
                        }
                        response.message = "";
                        response.success = true;
                        response.data = project;
                    }
                    else
                    {
                        response.message = "No records found";
                        response.success = false;
                    }
                }

            }
            catch (Exception ex)
            {
                response.message = ex.Message;
                response.success = false;
            }
            finally
            {
                await _connection.CloseAsync();
            }
            return response;
        }

        public async Task<ResponseModel<string>> UpdateProject(ProjectModel project)
        {
            ResponseModel<string> response = new ResponseModel<string>();
            try
            {
                await _connection.OpenAsync();

                using (NpgsqlCommand command = new NpgsqlCommand(@"UPDATE taskm.t_project
                SET  c_project_name=@c_project_name, c_description=@c_description
                WHERE c_project_id=@c_project_id;", _connection))
                {
                    command.Parameters.AddWithValue("c_project_id", project.projectId);
                    command.Parameters.AddWithValue("c_project_name", project.projectName);
                    command.Parameters.AddWithValue("c_description", project.description);
                    var result = await command.ExecuteNonQueryAsync();
                    if (result > 0)
                    {
                        response.success = true;
                        response.message = "Record Updated Succsessfully.";
                    }
                    else
                    {
                        response.success = false;
                        response.message = "Getting error while updating.";
                    }
                }

            }
            catch (Exception ex)
            {
                response.message = ex.Message;
                response.success = false;
            }
            finally
            {
                await _connection.CloseAsync();
            }
            return response;
        }
    }
}
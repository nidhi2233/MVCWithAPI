using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Npgsql;
using Repositories.InterFace;
using Repositories.Models;

namespace Repositories.implementation
{
    public class EmployeeRepository : IEmployeeInterFace
    {
        private readonly NpgsqlConnection _connection;

        public EmployeeRepository(NpgsqlConnection connection)
        {
            _connection = connection;
        }

        public async Task<ResponseModel<string>> AddEmployee(EmployeeModel employee)
        {
            ResponseModel<string> response = new ResponseModel<string>();
            try
            {
                
                var getEmploy = await GetEmployee(0, employee.email, employee.password);
                await _connection.OpenAsync();
                if (!getEmploy.success)
                {
                    using (NpgsqlCommand command = new NpgsqlCommand(@"INSERT INTO taskM.t_employees(
                    c_name, c_email, c_password, c_role, c_profile_image)
                    VALUES (@c_name, @c_email, @c_password, @c_role, @c_profile_image);", _connection))
                    {
                        command.Parameters.AddWithValue("c_name", employee.name);
                        command.Parameters.AddWithValue("c_email", employee.email);
                        command.Parameters.AddWithValue("c_password", employee.password);
                        command.Parameters.AddWithValue("c_role", employee.role!);
                        command.Parameters.AddWithValue("c_profile_image", employee.profileImage == null ? DBNull.Value : employee.profileImage);

                        var result = await command.ExecuteNonQueryAsync();
                        if (result > 0)
                        {
                            response.success = true;
                            response.message = "Record Inserted Succsessfully.";
                        }
                        else
                        {
                            response.success = false;
                            response.message = "Getting error while registration.";
                        }
                    }
                }
                else
                {
                    response.success = false;
                    response.message = "User All Ready Exist";
                }

            }
            catch (Exception ex)
            {
                response.message = ex.Message;
                response.success = false;
            }
            finally
            {
                await _connection.CloseAsync();
            }
            return response;
        }

        public async Task<ResponseModel<string>> DeleteEmployee(int id)
        {

            ResponseModel<string> response = new ResponseModel<string>();
            try
            {
                await _connection.OpenAsync();
                using (NpgsqlCommand command = new NpgsqlCommand(@"DELETE FROM taskm.t_employees WHERE c_emp_id=@c_emp_id;", _connection))
                {
                    command.Parameters.AddWithValue("c_emp_id", id);

                    var result = await command.ExecuteNonQueryAsync();
                    if (result > 0)
                    {
                        response.success = true;
                        response.message = "Record Deleted Succsessfully.";
                    }
                    else
                    {
                        response.success = false;
                        response.message = "Getting error while deleteing.";
                    }
                }

            }
            catch (Exception ex)
            {
                response.message = ex.Message;
                response.success = false;
            }
            finally
            {
                await _connection.CloseAsync();
            }
            return response;
        }

        public async Task<ResponseModel<List<EmployeeModel>>> GetAllEmployee()
        {
            ResponseModel<List<EmployeeModel>> response = new ResponseModel<List<EmployeeModel>>();
            List<EmployeeModel> listEmployees = new List<EmployeeModel>();
            try
            {
                await _connection.OpenAsync();


                using (NpgsqlCommand command = new NpgsqlCommand("SELECT c_emp_id, c_name, c_email, c_password, c_role, c_profile_image FROM taskm.t_employees;", _connection))
                {
                    NpgsqlDataReader dataReader = await command.ExecuteReaderAsync();
                    if (dataReader.HasRows)
                    {
                        while (dataReader.Read())
                        {
                            listEmployees.Add(new EmployeeModel
                            {
                                empId = Convert.ToInt32(dataReader["c_emp_id"]),
                                name = dataReader["c_name"].ToString()!,
                                email = dataReader["c_email"].ToString()!,
                                password = dataReader["c_password"].ToString()!,
                                role = dataReader["c_role"].ToString()!,
                                profileImage = dataReader["c_profile_image"].ToString()!,
                            });
                        }
                        response.message = "";
                        response.success = true;
                        response.data = listEmployees;
                    }
                    else
                    {
                        response.message = "No records found";
                        response.success = false;
                    }
                }

            }
            catch (Exception ex)
            {
                response.message = ex.Message;
                response.success = false;
            }
            finally
            {
                await _connection.CloseAsync();
            }
            return response;
        }

        public async Task<ResponseModel<EmployeeModel>> GetEmployee(int id = 0, string email = "", string password = "")
        {
            ResponseModel<EmployeeModel> response = new ResponseModel<EmployeeModel>();

            try
            {
                await _connection.OpenAsync();
                string query = null!;
                if (id != 0)
                {
                    query = @"SELECT c_emp_id, c_name, c_email, c_password, c_role, c_profile_image FROM taskm.t_employees WHERE c_emp_id=@c_emp_id;";
                }
                else if (email != "" && password != "")
                {
                    query = @"SELECT c_emp_id, c_name, c_email, c_password, c_role, c_profile_image FROM taskm.t_employees
                     WHERE c_email=@c_email AND c_password=@c_password;";
                }
                using (NpgsqlCommand command = new NpgsqlCommand(query, _connection))
                {
                    if (id != 0)
                    {
                        command.Parameters.AddWithValue("c_emp_id", id);
                    }
                    else
                    {
                        command.Parameters.AddWithValue("c_email", email);
                        command.Parameters.AddWithValue("c_password", password);
                    }

                    NpgsqlDataReader dataReader = await command.ExecuteReaderAsync();
                    if (dataReader.HasRows)
                    {
                        EmployeeModel employees = new EmployeeModel();
                        while (dataReader.Read())
                        {
                            employees.empId = Convert.ToInt32(dataReader["c_emp_id"]);
                            employees.name = dataReader["c_name"].ToString()!;
                            employees.email = dataReader["c_email"].ToString()!;
                            employees.password = dataReader["c_password"].ToString()!;
                            employees.role = dataReader["c_role"].ToString()!;
                            employees.profileImage = dataReader["c_profile_image"].ToString()!;
                        }
                        response.message = "";
                        response.success = true;
                        response.data = employees;
                    }
                    else
                    {
                        response.message = "No records found";
                        response.success = false;
                    }
                }

            }
            catch (Exception ex)
            {
                response.message = ex.Message;
                response.success = false;
            }
            finally
            {
                await _connection.CloseAsync();
            }
            return response;
        }

        public async Task<ResponseModel<string>> UpdateEmployee(EmployeeModel employee)
        {
            ResponseModel<string> response = new ResponseModel<string>();
            try
            {
                await _connection.OpenAsync();

                using (NpgsqlCommand command = new NpgsqlCommand(@"UPDATE taskm.t_employees
                SET c_name=@c_name, c_email=@c_email, c_password=@c_password, c_role=@c_role, c_profile_image=@c_profile_image
                WHERE c_emp_id=@c_emp_id", _connection))
                {
                    command.Parameters.AddWithValue("c_emp_id", employee.empId);
                    command.Parameters.AddWithValue("c_name", employee.name);
                    command.Parameters.AddWithValue("c_email", employee.email);
                    command.Parameters.AddWithValue("c_password", employee.password);
                    command.Parameters.AddWithValue("c_role", employee.role!);
                    command.Parameters.AddWithValue("c_profile_image", employee.profileImage == null ? DBNull.Value : employee.profileImage);

                    var result = await command.ExecuteNonQueryAsync();
                    if (result > 0)
                    {
                        response.success = true;
                        response.message = "Record Updated Succsessfully.";
                    }
                    else
                    {
                        response.success = false;
                        response.message = "Getting error while updating.";
                    }
                }

            }
            catch (Exception ex)
            {
                response.message = ex.Message;
                response.success = false;
            }
            finally
            {
                await _connection.CloseAsync();
            }
            return response;
        }
    }
}
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Npgsql;
using Repositories.InterFace;
using Repositories.Models;

namespace Repositories.implementation
{
    public class TaskRepository : ITaskInterFace
    {

        private readonly NpgsqlConnection _connection;

        public TaskRepository(NpgsqlConnection connection)
        {
            _connection = connection;
        }

        public async Task<ResponseModel<string>> AddTask(TaskModel task)
        {
            ResponseModel<string> response = new ResponseModel<string>();
            try
            {
                await _connection.OpenAsync();
                using (NpgsqlCommand command = new NpgsqlCommand(@"INSERT INTO taskm.t_task(
                c_project_id, c_emp_id, c_title, c_description, c_estimated_days, c_start_date, c_end_date)
                VALUES ( @c_project_id, @c_emp_id, @c_title, @c_description, @c_estimated_days, @c_start_date, @c_end_date);", _connection))
                {
                    command.Parameters.AddWithValue("c_project_id", task.projectId);
                    command.Parameters.AddWithValue("c_emp_id", task.empId);
                    command.Parameters.AddWithValue("c_title", task.title);
                    command.Parameters.AddWithValue("c_description", task.description);
                    command.Parameters.AddWithValue("c_estimated_days", task.estimatedDay);
                    command.Parameters.AddWithValue("c_start_date", task.startDate!);
                    command.Parameters.AddWithValue("c_end_date", task.endDate!);
                    var result = await command.ExecuteNonQueryAsync();
                    if (result > 0)
                    {
                        response.success = true;
                        response.message = "Record Inserted Succsessfully.";
                    }
                    else
                    {
                        response.success = false;
                        response.message = "Getting error while registration.";
                    }
                }

            }
            catch (Exception ex)
            {
                response.message = ex.Message;
                response.success = false;
            }
            finally
            {
                await _connection.CloseAsync();
            }
            return response;
        }

        public async Task<ResponseModel<string>> DeleteTask(int id)
        {
            ResponseModel<string> response = new ResponseModel<string>();
            try
            {
                await _connection.OpenAsync();
                using (NpgsqlCommand command = new NpgsqlCommand(@"DELETE FROM taskm.t_task WHERE c_task_id=@c_task_id;", _connection))
                {
                    command.Parameters.AddWithValue("c_task_id", id);
                    var result = await command.ExecuteNonQueryAsync();
                    if (result > 0)
                    {
                        response.success = true;
                        response.message = "Record Deleted Succsessfully.";
                    }
                    else
                    {
                        response.success = false;
                        response.message = "Getting error while deleteing.";
                    }
                }

            }
            catch (Exception ex)
            {
                response.message = ex.Message;
                response.success = false;
            }
            finally
            {
                await _connection.CloseAsync();
            }
            return response;
        }

        public async Task<ResponseModel<List<TaskModel>>> GetAllTaskAndById(int taskId = 0, int empId = 0, int projectId = 0)
        {
            ResponseModel<List<TaskModel>> response = new ResponseModel<List<TaskModel>>();
            List<TaskModel> listTask = new List<TaskModel>();
            try
            {
                await _connection.OpenAsync();
                string query = null!;
                if (taskId != 0)
                {
                    query = @"SELECT task.c_task_id, task.c_project_id,project.c_project_name, task.c_emp_id,emp.c_name, task.c_title, task.c_description, task.c_estimated_days, 
                    task.c_start_date, task.c_end_date, task.c_status FROM taskm.t_task as task 
                    JOIN taskm.t_project as project ON project.c_project_id = task.c_project_id
                    JOIN taskm.t_employees as emp ON emp.c_emp_id = task.c_emp_id WHERE task.c_task_id=@c_task_id;";
                }
                else if (empId != 0)
                {
                    query = @"SELECT task.c_task_id, task.c_project_id,project.c_project_name, task.c_emp_id,emp.c_name, task.c_title, task.c_description, task.c_estimated_days, 
                    task.c_start_date, task.c_end_date, task.c_status FROM taskm.t_task as task 
                    JOIN taskm.t_project as project ON project.c_project_id = task.c_project_id
                    JOIN taskm.t_employees as emp ON emp.c_emp_id = task.c_emp_id WHERE task.c_emp_id=@c_emp_id;";
                }
                else if (projectId != 0)
                {
                    query = @"SELECT task.c_task_id, task.c_project_id,project.c_project_name, task.c_emp_id,emp.c_name, task.c_title, task.c_description, task.c_estimated_days, 
                    task.c_start_date, task.c_end_date, task.c_status FROM taskm.t_task as task 
                    JOIN taskm.t_project as project ON project.c_project_id = task.c_project_id
                    JOIN taskm.t_employees as emp ON emp.c_emp_id = task.c_emp_id WHERE task.c_project_id=@c_project_id;";
                }
                else
                {
                    response.message = "No records found";
                    response.success = false;
                }
                using (NpgsqlCommand command = new NpgsqlCommand(query, _connection))
                {
                    command.Parameters.AddWithValue("c_task_id",taskId);
                    command.Parameters.AddWithValue("c_project_id",projectId);
                    command.Parameters.AddWithValue("c_emp_id",empId);
                    NpgsqlDataReader dataReader = await command.ExecuteReaderAsync();
                    if (dataReader.HasRows)
                    {
                        while (dataReader.Read())
                        {
                            listTask.Add(new TaskModel
                            {
                                taskId = Convert.ToInt32(dataReader["c_task_id"]),
                                projectId = Convert.ToInt32(dataReader["c_project_id"]),
                                empId = Convert.ToInt32(dataReader["c_emp_id"]),
                                title = dataReader["c_title"].ToString()!,
                                description = dataReader["c_description"].ToString()!,
                                estimatedDay = Convert.ToInt32(dataReader["c_estimated_days"]),
                                startDate = Convert.ToDateTime(dataReader["c_start_date"]),
                                endDate = Convert.ToDateTime(dataReader["c_end_date"]),
                                status = dataReader["c_status"].ToString()!,
                                project = new ProjectModel{
                                    projectName = dataReader["c_project_name"].ToString()!
                                },
                                employee = new EmployeeModel{
                                    name = dataReader["c_name"].ToString()!
                                }
                            });
                        }
                        response.message = "";
                        response.success = true;
                        response.data = listTask;
                    }
                    else
                    {
                        response.message = "No records found";
                        response.success = false;
                    }
                }

            }
            catch (Exception ex)
            {
                response.message = ex.Message;
                response.success = false;
            }
            finally
            {
                await _connection.CloseAsync();
            }
            return response;
        }

        public async Task<ResponseModel<TaskModel>> GetTaskById(int id)
        {
            ResponseModel<TaskModel> response = new ResponseModel<TaskModel>();
            TaskModel task = new TaskModel();
            try
            {
                await _connection.OpenAsync();
                using (NpgsqlCommand command = new NpgsqlCommand(@"SELECT c_task_id, c_project_id, c_emp_id, c_title, c_description, c_estimated_days, c_start_date, c_end_date, c_status
	            FROM taskm.t_task c_task_id@c_task_id", _connection))
                {
                    command.Parameters.AddWithValue("c_task_id", id);
                    NpgsqlDataReader dataReader = await command.ExecuteReaderAsync();
                    if (dataReader.HasRows)
                    {
                        while (dataReader.Read())
                        {
                            task.taskId = Convert.ToInt32(dataReader["c_task_id"]);
                            task.projectId = Convert.ToInt32(dataReader["c_project_id"]);
                            task.empId = Convert.ToInt32(dataReader["c_emp_id"]);
                            task.title = dataReader["c_title"].ToString()!;
                            task.description = dataReader["c_description"].ToString()!;
                            task.estimatedDay = Convert.ToInt32(dataReader["c_estimated_days"]);
                            task.startDate = Convert.ToDateTime(dataReader["c_start_date"]);
                            task.endDate = Convert.ToDateTime(dataReader["c_start_date"]);
                            task.status = dataReader["c_status"].ToString()!;
                        }
                        response.message = "";
                        response.success = true;
                        response.data = task;
                    }
                    else
                    {
                        response.message = "No records found";
                        response.success = false;
                    }
                }

            }
            catch (Exception ex)
            {
                response.message = ex.Message;
                response.success = false;
            }
            finally
            {
                await _connection.CloseAsync();
            }
            return response;
        }

        public async Task<ResponseModel<string>> UpdateTask(TaskModel task)
        {
            ResponseModel<string> response = new ResponseModel<string>();
            try
            {
                await _connection.OpenAsync();

                using (NpgsqlCommand command = new NpgsqlCommand(@"UPDATE taskm.t_task
                SET  c_title=@c_title, c_description=@c_description, c_estimated_days=@c_estimated_days, c_start_date=@c_start_date, c_end_date=@c_end_date, c_status=@c_status
                WHERE  c_task_id=@c_task_id;", _connection))
                {
                    command.Parameters.AddWithValue("c_project_id", task.projectId);
                    command.Parameters.AddWithValue("c_emp_id", task.empId);
                    command.Parameters.AddWithValue("c_title", task.title);
                    command.Parameters.AddWithValue("c_description", task.description);
                    command.Parameters.AddWithValue("c_estimated_days", task.estimatedDay);
                    command.Parameters.AddWithValue("c_start_date", task.startDate!);
                    command.Parameters.AddWithValue("c_end_date", task.endDate!);
                    command.Parameters.AddWithValue("c_status", task.status!);
                    command.Parameters.AddWithValue("c_task_id", task.taskId);
                    var result = await command.ExecuteNonQueryAsync();
                    if (result > 0)
                    {
                        response.success = true;
                        response.message = "Record Updated Succsessfully.";
                    }
                    else
                    {
                        response.success = false;
                        response.message = "Getting error while updating.";
                    }
                }

            }
            catch (Exception ex)
            {
                response.message = ex.Message;
                response.success = false;
            }
            finally
            {
                await _connection.CloseAsync();
            }
            return response;
        }
    }
}
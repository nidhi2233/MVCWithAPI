using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Repositories.Models;

namespace Repositories.InterFace
{
    public interface IEmployeeInterFace 
    {
        public Task<ResponseModel<List<EmployeeModel>>> GetAllEmployee();
        public Task<ResponseModel<EmployeeModel>> GetEmployee(int id=0,string email="",string password="");
        public Task<ResponseModel<string>> AddEmployee(EmployeeModel employee);
        public Task<ResponseModel<string>> UpdateEmployee(EmployeeModel employee);
        public Task<ResponseModel<string>> DeleteEmployee(int id);

    }
}
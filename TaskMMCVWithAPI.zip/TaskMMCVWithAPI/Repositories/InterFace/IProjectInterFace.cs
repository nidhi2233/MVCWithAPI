using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Repositories.Models;

namespace Repositories.InterFace
{
    public interface IProjectInterFace
    {
        public Task<ResponseModel<List<ProjectModel>>> GetAllProject();
        public Task<ResponseModel<ProjectModel>> GetProjectById(int id);
        public Task<ResponseModel<string>> AddProject(ProjectModel project);
        public Task<ResponseModel<string>> UpdateProject(ProjectModel project);
        public Task<ResponseModel<string>> DeleteProject(int id);
    }
}
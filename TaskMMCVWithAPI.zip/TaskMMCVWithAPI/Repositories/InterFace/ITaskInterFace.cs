using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Repositories.Models;

namespace Repositories.InterFace
{
    public interface ITaskInterFace
    {
        public Task<ResponseModel<List<TaskModel>>> GetAllTaskAndById(int taskId=0,int empId=0,int projectId=0);
        public Task<ResponseModel<TaskModel>> GetTaskById(int id);
        public Task<ResponseModel<string>> AddTask(TaskModel task);
        public Task<ResponseModel<string>> UpdateTask(TaskModel task);
        public Task<ResponseModel<string>> DeleteTask(int id);
    }
}
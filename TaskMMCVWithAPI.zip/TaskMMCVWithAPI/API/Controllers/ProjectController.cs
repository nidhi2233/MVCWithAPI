using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Repositories.InterFace;
using Repositories.Models;

namespace API.Controllers
{
    
    [ApiController]
    [Route("api/[controller]")]
    public class ProjectController : ControllerBase
    {
        private readonly IProjectInterFace _projectRepo;
        public ResponseModel<string> _response;

        public ProjectController(IProjectInterFace projectRepo)
        {
            _projectRepo = projectRepo;
            _response = new ResponseModel<string>();
        }

        [HttpPost("AddProject")]
        [Authorize(Roles = "Admin")]
        public async Task<IActionResult> AddProject([FromForm] ProjectModel project)
        {
            if (ModelState.IsValid)
            {
                var response = await _projectRepo.AddProject(project);
                if (response.success)
                {
                    return Ok(new { response.success, response.message, response.data });
                }
                else
                {
                    return Ok(new { response.success, response.message, response.data });
                }
            }
            else
            {
                return Ok(_response);
            }
        }

        [HttpGet("GetProjectById/{id}")]
        [Authorize(Roles = "Employee")]
        public async Task<IActionResult> GetProjectById(int id)
        {
            var response = await _projectRepo.GetProjectById(id); 
            if (response.success)
            {
                return Ok(new { response.success, response.message, response.data });
            }
            else
            {
                return Ok(new { response.success, response.message, response.data });
            }

        }

        [HttpGet("GetAllProject")]
        [Authorize(Roles = "Employee")]
        public async Task<IActionResult> GetAllProject()
        {
            var response = await _projectRepo.GetAllProject();
            if (response.success)
            {
                return Ok(new { response.success, response.message, response.data });
            }
            else
            {
                return Ok(new { response.success, response.message, response.data });
            }

        }

        [HttpPut("UpdateProject")]
        [Authorize(Roles = "Admin")]
        public async Task<IActionResult> UpdateProject([FromForm] ProjectModel project)
        {
            if (ModelState.IsValid)
            {
                var response = await _projectRepo.UpdateProject(project);
                if (response.success)
                {
                    return Ok(new { response.success, response.message, response.data });
                }
                else
                {
                    return Ok(new { response.success, response.message, response.data });
                }
            }
            else
            {
                return Ok(_response);
            }
        }

        [HttpDelete("DeleteProject/{id}")]
        [Authorize(Roles = "Admin")]
        public async Task<IActionResult> DeleteEmployee(int id)
        {
            var response = await _projectRepo.DeleteProject(id);
            if (response.success)
            {
                return Ok(new { response.success, response.message, response.data });
            }
            else
            {
                return Ok(new { response.success, response.message, response.data });
            }
        }
    }
}
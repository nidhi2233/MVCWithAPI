using System;
using System.Collections.Generic;
using System.IdentityModel.Tokens.Jwt;
using System.Linq;
using System.Security.Claims;
using System.Text;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.IdentityModel.Tokens;
using Repositories.implementation;
using Repositories.InterFace;
using Repositories.Models;

namespace API.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class EmployeeController : ControllerBase
    {
        private readonly IEmployeeInterFace _empRepo;
        private readonly IConfiguration _configer;
        public ResponseModel<string> _response;

        public EmployeeController(IEmployeeInterFace empRepo, IConfiguration configuration)
        {
            _empRepo = empRepo;
            _configer = configuration;
            _response = new ResponseModel<string>();
        }

        [HttpPost("Login")]
        public async Task<IActionResult> Login([FromForm] Vm_login login)
        {
            if (ModelState.IsValid)
            {
                var response = await _empRepo.GetEmployee(0, login.email, login.password);
                if (response.success)
                {
                    var claims = new[]{
                        new Claim(JwtRegisteredClaimNames.Jti, Guid.NewGuid().ToString()),
                        new Claim("empId",response.data!.empId.ToString()),
                        new Claim("email",response.data!.email),
                        new Claim(ClaimTypes.Role,response.data!.role!),
                    };
                    var key = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(_configer["Jwt:Key"]!));
                    var signIn = new SigningCredentials(key, SecurityAlgorithms.HmacSha256);
                    var token = new JwtSecurityToken(
                        issuer: _configer["Jwt:Issuer"],
                        audience: _configer["Jwt:Audience"],
                        claims: claims,
                        expires: DateTime.UtcNow.AddDays(1),
                        signingCredentials: signIn
                    );
                    response.message = "Login Succsessfully Done.";
                    string url = null!;
                    if (response.data.role == "Admin")
                    {
                        url = "/Admin/Home";
                    }
                    else
                    {
                        url = "/Employee/Index";
                    }
                    return Ok(new { response.success, response.message, response.data, token = new JwtSecurityTokenHandler().WriteToken(token), url });
                }
                else
                {
                    return Ok(new { response.success, response.message, response.data });
                }
            }
            else
            {
                return Ok(_response);
            }
        }

        [HttpGet("CheckRole")]
        [Authorize]
        public IActionResult CheckRole(int id)
        {
            _response.success = User.IsInRole("Admin");
            _response.message = "Token Check";
            return Ok(new { _response.success, _response.message });
        }

        [HttpPost("Rigister")]
        public async Task<IActionResult> Rigister([FromForm] EmployeeModel employee)
        {
            if (ModelState.IsValid)
            {
                if (employee.formFile != null && employee.formFile.Length > 0)
                {
                    var fileName = employee.email + Path.GetExtension(employee.formFile.FileName);
                    var filPath = Path.Combine("../MVC/wwwroot/profile_image", fileName);
                    employee.profileImage = fileName.ToString();
                    using (var stram = new FileStream(filPath, FileMode.Create))
                    {
                        await employee.formFile.CopyToAsync(stram);
                    }
                }
                var response = await _empRepo.AddEmployee(employee);
                if (response.success)
                {

                    return Ok(new { response.success, response.message, response.data });
                }
                else
                {
                    return Ok(new { response.success, response.message, response.data });
                }
            }
            else
            {
                return Ok(_response);
            }
        }

        [HttpGet("GetEmployeeById/{id}")]
        [Authorize]
        public async Task<IActionResult> GetEmployee(int id)
        {
            var response = await _empRepo.GetEmployee(id, "", "");
            if (response.success)
            {
                return Ok(new { response.success, response.message, response.data });
            }
            else
            {
                return Ok(new { response.success, response.message, response.data });
            }
        }

        [HttpGet("GetAllEmployee")]
        [Authorize]
        public async Task<IActionResult> GetAllEmployee()
        {
            var response = await _empRepo.GetAllEmployee();
            if (response.success)
            {
                return Ok(new { response.success, response.message, response.data });
            }
            else
            {
                return Ok(new { response.success, response.message, response.data });
            }

        }

        [HttpPut("UpdateEmployee")]
        [Authorize]
        public async Task<IActionResult> UpdateEmployee([FromForm] EmployeeModel employee)
        {
            if (ModelState.IsValid)
            {
                var response = await _empRepo.UpdateEmployee(employee);
                if (response.success)
                {
                    if (employee.formFile != null && employee.formFile.Length > 0)
                    {
                        var fileName = employee.email + Path.GetExtension(employee.formFile.FileName);
                        var filPath = Path.Combine("../MVC/wwwroot/profile_image", fileName);
                        employee.profileImage = fileName.ToString();
                        using (var stram = new FileStream(filPath, FileMode.Create))
                        {
                            await employee.formFile.CopyToAsync(stram);
                        }
                    }
                    return Ok(new { response.success, response.message, response.data });
                }
                else
                {
                    return Ok(new { response.success, response.message, response.data });
                }
            }
            else
            {
                return Ok(_response);
            }
        }

        [HttpDelete("DeleteEmployee/{id}")]
        [Authorize]
        public async Task<IActionResult> DeleteEmployee(int id)
        {
            var response = await _empRepo.DeleteEmployee(id);
            if (response.success)
            {
                return Ok(new { response.success, response.message, response.data });
            }
            else
            {
                return Ok(new { response.success, response.message, response.data });
            }
        }
    }
}
async function callAjax(method,url,data=null,isFormData=false,token=null){
    return new Promise((resolve,reject)=>{
        const ajaxProperties = {
            type:method,
            method:method,
            url:url,
            data:data,
            dataType:"JSON"
        }      
        
        if(token != null){
            ajaxProperties.headers = {
                'Authorization' : 'Bearer ' + token
            }
        }
        
        if (isFormData) {
            ajaxProperties.processData = false;
            ajaxProperties.contentType = false;
            ajaxProperties.data = data;  // Set FormData directly without serialization
        } else if (data) {
            ajaxProperties.data = JSON.stringify(data);
            ajaxProperties.contentType = "application/json; charset=utf-8";
        }
        
        $.ajax({
            ...ajaxProperties,
            success:(resposne)=>{
                resolve(resposne);
            },
            error:(err)=>{
                reject(err);
            }
        })
    })
}